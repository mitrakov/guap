// Copyright (c) 2019, the Dart project authors. Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

dynamic /*member: x1:assigned={a}*/ x1 = /*declared={a, b}*/ (int a, int b) {
  a = 0;
};

/*member: x2:none*/
final x2 = new List.filled(0, null);
